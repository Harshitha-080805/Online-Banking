<?php
include __DIR__ . "/db.php";  // Ensure database connection is correct

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sender_account = $_POST["sender_account"];
    $recipient_account = $_POST["recipient_account"];
    $amount = floatval($_POST["amount"]);

    if ($amount <= 0) {
        echo json_encode(["success" => false, "error" => "Invalid amount!"]);
        exit;
    }

    $conn->begin_transaction();

    // Get sender details
    $stmt = $conn->prepare("SELECT id, balance FROM users WHERE account_number = ?");
    $stmt->bind_param("s", $sender_account);
    $stmt->execute();
    $result = $stmt->get_result();
    $sender = $result->fetch_assoc();

    if (!$sender) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Sender not found!"]);
        exit;
    }

    // Check if sender has enough balance
    if ($sender["balance"] < $amount) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Insufficient funds!"]);
        exit;
    }

    // Get recipient details
    $stmt = $conn->prepare("SELECT id FROM users WHERE account_number = ?");
    $stmt->bind_param("s", $recipient_account);
    $stmt->execute();
    $result = $stmt->get_result();
    $recipient = $result->fetch_assoc();

    if (!$recipient) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Recipient not found!"]);
        exit;
    }

    // Deduct amount from sender
    $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE account_number = ?");
    $stmt->bind_param("ds", $amount, $sender_account);
    if (!$stmt->execute()) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Failed to deduct sender balance!"]);
        exit;
    }

    // Add amount to recipient
    $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE account_number = ?");
    $stmt->bind_param("ds", $amount, $recipient_account);
    if (!$stmt->execute()) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Failed to add recipient balance!"]);
        exit;
    }

    // Log transaction for sender
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, status) VALUES (?, ?, 'debit', 'completed')");
    $stmt->bind_param("id", $sender["id"], $amount);
    if (!$stmt->execute()) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Failed to record sender transaction!"]);
        exit;
    }

    // Log transaction for recipient
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, status) VALUES (?, ?, 'credit', 'completed')");
    $stmt->bind_param("id", $recipient["id"], $amount);
    if (!$stmt->execute()) {
        $conn->rollback();
        echo json_encode(["success" => false, "error" => "Failed to record recipient transaction!"]);
        exit;
    }

    // Commit transaction
    $conn->commit();
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => "Invalid request!"]);
}
?>
