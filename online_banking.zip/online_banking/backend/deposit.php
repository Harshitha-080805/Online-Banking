<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "error" => "User not logged in."]);
    exit();
}

require_once "db.php";

$user_id = $_SESSION['user_id'];
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;

// Validate amount
if ($amount <= 0) {
    echo json_encode(["success" => false, "error" => "Invalid deposit amount."]);
    exit();
}

// Check if user exists
$user_check = $conn->prepare("SELECT balance FROM users WHERE id = ?");
$user_check->bind_param("i", $user_id);
$user_check->execute();
$user_result = $user_check->get_result();

if ($user_result->num_rows === 0) {
    echo json_encode(["success" => false, "error" => "User not found."]);
    exit();
}

// Fetch balance
$user_data = $user_result->fetch_assoc();
$current_balance = $user_data['balance'];
$new_balance = $current_balance + $amount;

// Update balance
$update_balance = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
$update_balance->bind_param("di", $new_balance, $user_id);
if (!$update_balance->execute()) {
    echo json_encode(["success" => false, "error" => "Failed to update balance: " . $conn->error]);
    exit();
}

// Insert transaction
$transaction = $conn->prepare("INSERT INTO transactions (user_id, amount, type, status) VALUES (?, ?, 'credit', 'completed')");
$transaction->bind_param("id", $user_id, $amount);
if (!$transaction->execute()) {
    echo json_encode(["success" => false, "error" => "Failed to record transaction: " . $conn->error]);
    exit();
}

// Success response
echo json_encode(["success" => true, "message" => "Deposit successful!"]);
?>
