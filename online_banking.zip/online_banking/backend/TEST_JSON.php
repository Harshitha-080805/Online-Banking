<?php
echo json_encode(["status" => "JSON is working!"]);
?>
