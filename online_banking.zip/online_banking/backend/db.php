


<?php
$host = "localhost";  
$username = "root";  // Default MySQL user in XAMPP
$password = "";      // Default password (empty)
$database = "online_banking"; // Replace with your actual database name

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Uncomment this to verify the connection
// echo "Database connected successfully!";

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

?>
