<?php
session_start();
require_once "db.php"; // Ensure the correct path to database connection file

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "error" => "User not logged in"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = isset($_POST['amount']) ? (float) $_POST['amount'] : 0;

error_log("POST request received.");
error_log("Amount: " . $amount);

if ($amount <= 0) {
    echo json_encode(["success" => false, "error" => "Invalid withdrawal amount"]);
    exit();
}

// Fetch current balance
$stmt = $conn->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo json_encode(["success" => false, "error" => "User not found"]);
    exit();
}

$current_balance = (float) $user['balance'];

// Check if sufficient balance is available
if ($amount > $current_balance) {
    echo json_encode(["success" => false, "error" => "Insufficient funds"]);
    exit();
}

// Deduct amount from balance
$new_balance = $current_balance - $amount;
$update_stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
$update_stmt->bind_param("di", $new_balance, $user_id);
$update_stmt->execute();

if ($update_stmt->affected_rows === 0) {
    echo json_encode(["success" => false, "error" => "Failed to update balance"]);
    exit();
}

// Record transaction in `transactions` table
$insert_stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, status) VALUES (?, ?, 'withdraw', 'completed')");
$insert_stmt->bind_param("id", $user_id, $amount);
$insert_stmt->execute();

if ($insert_stmt->affected_rows === 0) {
    echo json_encode(["success" => false, "error" => "Failed to record transaction"]);
    exit();
}

echo json_encode(["success" => true, "message" => "Withdrawal successful"]);
?>
