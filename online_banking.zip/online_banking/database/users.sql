-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 07:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_banking`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `account_number` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `balance`, `account_number`, `phone`) VALUES
(2, 'sreeha', '22nu1a05b0@nsrit.edu.in', '$2y$10$/vhbPZnDs2qIZeGMefoztuQ6b8e63ui2.NE1ArMspW4DxQ9UdwJ4G', 700.00, '8213068330', '1234567891'),
(4, 'harika', 'sreehavundavilli@gmail.com', '$2y$10$GJNSu24zATZhGidU3NqAm.l5RvduIjQKhZlkWeDCCTM89IFF77mOS', 1035.00, '2581346169', ''),
(5, 'abcd', 'sreehavundavilli2637@gmail.com', '$2y$10$RF/pEbukJqVT4qvVY2A4TOO4awKReC4T/6gLkaCwR/uLp3PBFifAO', 0.00, '4058503537', ''),
(6, 'harikass', 'sreehavundavilli1930@gmail.com', '$2y$10$VD3.XpUu9sYkKQdpvD8CxumhYJvtHyi1nbihNL39TrxMQ7st9gkyW', 0.00, '3358961178', '06372948205'),
(8, 'qwertyu', '22nu1a05b8@nsrit.edu.in', '$2y$10$G4382bE/BMkfmUDJjn377O.wwDB7vAKkiN91yjXZMilF2zOzjv39K', 111.00, '2120318434', '6372948205'),
(10, 'v sreeha', 'vsreeha@gmail.com', '', 1500.00, '6970852133', '06372948205'),
(11, 'harshitha', 'thotaharshitha143@gmail.com', '', 44000.00, '8296791750', '9110798358'),
(13, 'sreeha26', '22nu1a05b6@nsrit.edu.in', '', 2000.00, '9426364745', '6370873932');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `account_number` (`account_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
