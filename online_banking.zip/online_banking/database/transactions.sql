-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2025 at 07:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_banking`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('credit','debit') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `amount`, `type`, `created_at`, `status`) VALUES
(1, 8, 100.00, 'credit', '2025-03-09 08:58:35', 'completed'),
(2, 8, 34.00, '', '2025-03-09 09:22:35', 'completed'),
(3, 8, 20.00, '', '2025-03-09 09:24:42', 'completed'),
(4, 8, 2000.00, 'credit', '2025-03-09 09:28:21', 'completed'),
(5, 8, 200.00, '', '2025-03-09 09:28:31', 'completed'),
(6, 8, 345.00, 'debit', '2025-03-09 10:11:05', 'completed'),
(7, 4, 345.00, 'credit', '2025-03-09 10:11:05', 'completed'),
(8, 8, 345.00, 'debit', '2025-03-09 10:22:35', 'completed'),
(9, 4, 345.00, 'credit', '2025-03-09 10:22:35', 'completed'),
(10, 8, 345.00, 'debit', '2025-03-09 10:24:45', 'completed'),
(11, 4, 345.00, 'credit', '2025-03-09 10:24:45', 'completed'),
(12, 10, 1000.00, 'credit', '2025-03-09 10:56:19', 'completed'),
(13, 10, 500.00, '', '2025-03-09 10:56:41', 'completed'),
(14, 8, 250.00, 'debit', '2025-03-09 10:57:09', 'completed'),
(15, 2, 250.00, 'credit', '2025-03-09 10:57:09', 'completed'),
(16, 8, 250.00, 'debit', '2025-03-09 16:30:49', 'completed'),
(17, 2, 250.00, 'credit', '2025-03-09 16:30:49', 'completed'),
(18, 8, 200.00, 'debit', '2025-03-09 16:38:14', 'completed'),
(19, 2, 200.00, 'credit', '2025-03-09 16:38:14', 'completed'),
(20, 10, 1000.00, 'credit', '2025-03-09 16:43:03', 'completed'),
(21, 11, 50000.00, 'credit', '2025-03-11 06:06:17', 'completed'),
(22, 11, 6000.00, '', '2025-03-11 06:06:34', 'completed'),
(23, 13, 5000.00, 'credit', '2025-03-26 02:22:36', 'completed'),
(24, 13, 3000.00, '', '2025-03-26 02:23:20', 'completed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
