<?php
session_start();
require __DIR__ . '/../backend/config.php'; // Ensure the path is correct

// Redirect to login if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Fetch user details
$user_id = $_SESSION["user_id"];
$sql = "SELECT username, balance, account_number FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $balance, $account_number);
$stmt->fetch();
$stmt->close();

// Fetch recent transactions
$transactions = [];
$sql = "SELECT created_at AS date, type, amount, status FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $transactions[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Banking Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Header Styling */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: grey;
            color: white;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: bold;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        .header .profile {
            display: flex;
            align-items: center;
        }
        .profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .header .logout {
            background: red;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .welcome-message {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            font-size: 20px;
        }
        /* Main Container */
        .container {
            display: flex;
            width: 90%;
            margin: 20px auto;
            height: 100vh;
        }
        .sidebar {
            width: 25%;
            background: white;
            padding: 20px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        .main-content {
            width: 75%;
            padding: 20px;
            background: white;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-left: 10px;
        }
        .button-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        .button {
            background-color: #2196F3;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: block;
        }
        .transactions {
            padding: 15px;
            background: white;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .transactions table {
            width: 100%;
            border-collapse: collapse;
        }
        .transactions th, .transactions td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .transactions th {
            background: #2196F3;
            color: white;
        }
    </style>
</head>
<body>

    <!-- Header Section -->
<div class="header">
    <div class="profile">
        <a href="profile.php">
            <img src="https://www.w3schools.com/howto/img_avatar.png" alt="Profile">
        </a>
        <?php echo htmlspecialchars($username); ?>
    </div>
    <div class="welcome-message">Welcome to Online Banking</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Welcome, <?php echo htmlspecialchars($username); ?></h2>
            <p><strong>Account Balance:</strong> $<?php echo number_format($balance, 2); ?></p>
            <p><strong>Account Number:</strong> <?php echo htmlspecialchars($account_number); ?></p>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="button-grid">
                <a href="deposit.php" class="button">Deposit</a>
                <a href="withdraw.php" class="button">Withdraw</a>
                <a href="transfer.php" class="button">Transfer</a>
                <a href="history.php" class="button">Transaction History</a>
            </div>

            <div class="transactions">
                <h3>Recent Transactions</h3>
                <table>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                    <?php if (count($transactions) > 0): ?>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($transaction['date']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['type']); ?></td>
                                <td>$<?php echo number_format($transaction['amount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($transaction['status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center;">No transactions found</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
