<header>
    <div class="header-container">
        <h1 class="header-title">Welcome to Online Banking</h1>
        <div class="header-buttons">
            <a href="login.php" class="btn btn-lightblue">Login</a>
            <a href="register.php" class="btn btn-lightblue">Register</a>
        </div>
    </div>
</header>