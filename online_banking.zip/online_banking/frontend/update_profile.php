<?php
session_start();
require __DIR__ . '/../backend/config.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION["user_id"];
    $new_username = $_POST['username'];
    $new_email = $_POST['email'];
    $new_phone = $_POST['phone'];

    $sql = "UPDATE users SET username=?, email=?, phone=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $new_username, $new_email, $new_phone, $user_id);
    
    if ($stmt->execute()) {
        $_SESSION["username"] = $new_username;
        header("Location: profile.php?success=1");
        exit();
    } else {
        echo "Error updating profile.";
    }
    $stmt->close();
}
?>
