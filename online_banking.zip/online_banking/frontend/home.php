<?php
// Include the database connection (ensure this path is correct)
require '../backend/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Online Banking</title>
    <link rel="stylesheet" href="../frontend/assets/styles.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: #eef2f3;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .header {
            background: grey;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header-buttons a {
            background-color: blue;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-left: 10px;
            font-weight: bold;
        }

        .header-buttons a:hover {
            background-color: darkblue;
        }

        .main-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 20px;
        }

        .bank-image {
            max-width: 70%;
            height: auto;
            border-radius: 12px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 15px 0;
        }
    </style>
</head>
<body>
    <header class="header">
        <span>Welcome to Online Banking</span>
        <div class="header-buttons">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </header>
    <div class="main-content">
        <img src="../frontend/assets/bank-image.jpg" alt="Banking Image" class="bank-image">
    </div>
    <footer class="footer">
        &copy; 2025 Online Banking. Secure & Reliable Banking.
    </footer>
</body>
</html>
