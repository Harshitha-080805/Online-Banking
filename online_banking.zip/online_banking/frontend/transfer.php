<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Transfer</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; }
        form { display: inline-block; text-align: left; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        label, input { display: block; margin-bottom: 10px; width: 100%; }
        button { padding: 8px 12px; background-color: #28a745; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #218838; }
        #message { margin-top: 10px; display: none; }
        .dashboard-link { display: block; margin-top: 10px; text-decoration: none; color: #007bff; }
    </style>
</head>
<body>
    <h2>Transfer Funds</h2>
    <form id="transferForm">
        <input type="hidden" id="sender_account" value="2120318434">
        <label for="recipient">Recipient Account Number:</label>
        <input type="text" id="recipient" required>
        <label for="amount">Amount:</label>
        <input type="number" id="amount" required>
        <button type="submit">Transfer</button>
    </form>
    <p id="message"></p>
    <a href="dashboard.php" class="dashboard-link">Back to Dashboard</a>

    <script>
        document.getElementById("transferForm").addEventListener("submit", function(event) {
            event.preventDefault();
            let sender = document.getElementById("sender_account").value;
            let recipient = document.getElementById("recipient").value;
            let amount = document.getElementById("amount").value;
            let messageBox = document.getElementById("message");

            if (amount <= 0 || recipient.trim() === "") {
                messageBox.style.color = "red";
                messageBox.innerText = "Enter valid details!";
                messageBox.style.display = "block";
                return;
            }

            fetch("transfer.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({
                    sender_account: sender,
                    recipient_account: recipient,
                    amount: amount
                })
            })
            .then(response => response.json())
            .then(data => {
                messageBox.style.display = "block";
                if (data.success) {
                    messageBox.style.color = "green";
                    messageBox.innerText = "Transfer Successful! Redirecting...";
                    setTimeout(() => { window.location.href = "dashboard.php"; }, 2000);
                } else {
                    messageBox.style.color = "red";
                    messageBox.innerText = "Error: " + data.error;
                }
            })
            .catch(error => {
                console.error("Fetch Error:", error);
                messageBox.style.color = "red";
                messageBox.innerText = "Something went wrong!";
                messageBox.style.display = "block";
            });
        });
    </script>
</body>
</html>
