<footer>
    <p>© 2025 Online Banking. Secure & Reliable Banking.</p>
</footer>