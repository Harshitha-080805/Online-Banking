<?php
session_start();
require __DIR__ . '/../backend/config.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$message = "";

// Fetch user data securely
$sql = "SELECT id, username, email, phone, account_number FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $password = trim($_POST["password"]);

    // Hash the password only if it has been changed
    $hashed_password = (!empty($password)) ? password_hash($password, PASSWORD_DEFAULT) : $user["password"];

    // Update query (excluding account_number)
    $update_sql = "UPDATE users SET username=?, email=?, phone=?, password=? WHERE id=?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssssi", $username, $email, $phone, $hashed_password, $user_id);

    if ($stmt->execute()) {
        $_SESSION["message"] = "<p style='color:green; font-weight:bold;'>Profile successfully updated!</p>";
    } else {
        $_SESSION["message"] = "<p style='color:red;'>Error updating profile.</p>";
    }
    $stmt->close();

    // Redirect to prevent form resubmission issues
    header("Location: profile.php");
    exit();
}

$message = $_SESSION["message"] ?? "";
unset($_SESSION["message"]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .profile-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            width: 40%;
        }
        .message {
            text-align: center;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <h2 class="text-center">User Profile</h2>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>

    <form class="profile-form" method="POST">
        <div class="mb-3">
            <label class="form-label">User ID:</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['id']); ?>" disabled>
        </div>
        <div class="mb-3">
            <label class="form-label">Username:</label>
            <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Email:</label>
            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone:</label>
            <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">New Password (leave blank to keep current):</label>
            <input type="password" name="password" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Account Number:</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['account_number']); ?>" disabled>
        </div>
        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-primary w-50">Update Profile</button>
            <a href="dashboard.php" class="btn btn-secondary w-50">Back to Dashboard</a>
        </div>
    </form>
</div>

</body>
</html>
