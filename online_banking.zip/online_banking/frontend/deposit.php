<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Funds</title>
    <link rel="stylesheet" href="assets/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }
        .deposit-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }
        h2 { margin-bottom: 10px; }
        .input-field {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover { background-color: #218838; }
        .message {
            margin-top: 10px;
            font-weight: bold;
            color: green;
        }
    </style>
</head>
<body>

    <div class="deposit-container">
        <h2>Deposit Funds</h2>
        <input type="number" id="amount" class="input-field" placeholder="Enter amount" required>
        <button class="btn" onclick="makeDeposit()">Deposit</button>
        <p class="message" id="message"></p>
        <br>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <script>
        function makeDeposit() {
            let amount = document.getElementById("amount").value;
            let messageBox = document.getElementById("message");

            if (amount <= 0 || isNaN(amount)) {
                messageBox.style.color = "red";
                messageBox.innerText = "Enter a valid amount!";
                return;
            }

            // Send request to backend
            fetch("../backend/deposit.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                credentials: 'include', // Ensures session is carried over
                body: "amount=" + encodeURIComponent(amount)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    messageBox.style.color = "green";
                    messageBox.innerText = "Deposit Successful! Redirecting...";
                    setTimeout(() => {
                        window.location.href = "dashboard.php"; // Redirect after 2 sec
                    }, 2000);
                } else {
                    messageBox.style.color = "red";
                    messageBox.innerText = "Error: " + data.error;
                }
            })
            .catch(error => {
                messageBox.style.color = "red";
                messageBox.innerText = "Something went wrong!";
                console.error(error);
            });
        }
    </script>

</body>
</html>
s