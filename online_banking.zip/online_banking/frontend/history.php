<!-- transaction_history.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History</title>
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>
    <h2>Transaction History</h2>
    <button onclick="fetchHistory()">Load History</button>
    <table id="historyTable">
        <thead>
            <tr>
                <th>Amount</th>
                <th>Type</th>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
    <script>
        function fetchHistory() {
            fetch("http://localhost/online_banking/backend/history.php")

                .then(response => response.json())
                .then(data => {
                    let tableBody = document.querySelector("#historyTable tbody");
                    tableBody.innerHTML = "";
                    data.forEach(txn => {
                        let row = `<tr>
                            <td>${txn.amount}</td>
                            <td>${txn.type}</td>
                            <td>${txn.created_at}</td>
                            <td>${txn.status}</td>
                        </tr>`;
                        tableBody.innerHTML += row;
                    });
                })
                .catch(error => console.error("Error fetching history:", error));
        }
    </script>
</body>
</html>
